<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="68"/>
        <location filename="../mainwindow.cpp" line="302"/>
        <location filename="../mainwindow.cpp" line="321"/>
        <source>MX System Sounds</source>
        <translation>MX Systémové zvuky</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="47"/>
        <source>Event Sounds</source>
        <translation>Zvuky událostí</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>Session Sounds</source>
        <translation>Zvuky relace</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="66"/>
        <source>XFCE Event Sounds</source>
        <translation>Zvuky událostí XFCE</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="73"/>
        <source>Login</source>
        <translation>Příhlášení</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="80"/>
        <source>XFCE Input Feedback Sounds</source>
        <translation>Zvuky zpětné vazby XFCE</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="87"/>
        <source>Logout</source>
        <translation>Odhlášení</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="115"/>
        <source>Custom Sounds</source>
        <translation>Vlastní zvuky</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="122"/>
        <source>Theme</source>
        <translation>Motiv</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="129"/>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Login Sound</source>
        <translation>Zvuk při přihlášení</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="136"/>
        <location filename="../mainwindow.ui" line="182"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="161"/>
        <location filename="../mainwindow.ui" line="204"/>
        <location filename="../mainwindow.ui" line="207"/>
        <source>Theme Default</source>
        <translation>Předvolený motiv</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="164"/>
        <source>Use Default</source>
        <translation>Použít předvolený</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="175"/>
        <location filename="../mainwindow.ui" line="193"/>
        <source>Logout Sound</source>
        <translation>Zvuk při odhlášení</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="226"/>
        <source>Borealis</source>
        <translation>Borealis</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="257"/>
        <source>About this application</source>
        <translation>O této aplikaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="260"/>
        <source>About...</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="267"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Display help </source>
        <translation>Zobrazit nápovědu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="286"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="293"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="351"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Quit application</source>
        <translation>Ukončit aplikaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="380"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="387"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="301"/>
        <source>About MX System Sounds</source>
        <translation>O programu MX Systémové zvuky</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="302"/>
        <source>Version: </source>
        <translation>Verze:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="303"/>
        <source>Configure Event &amp; Session Sounds</source>
        <translation>Konfigurace zvuků událostí a relace</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="306"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Vlastnická práva (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="307"/>
        <source>%1 License</source>
        <translation>Licence %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="321"/>
        <source>%1 Help</source>
        <translation>Nápověda %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="336"/>
        <location filename="../mainwindow.cpp" line="365"/>
        <source>Select Sound File</source>
        <translation>Vyberte zvukový soubor</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="337"/>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Sound Files (*.mp3 *.m4a *.aac *.flac *.ogg *.oga *.wav)</source>
        <translation>Soubory zvuku (*.mp3 *.m4a *.aac *.flac *.ogg *.oga *.wav)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="40"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="41"/>
        <location filename="../about.cpp" line="51"/>
        <source>Changelog</source>
        <translation>Protokol změn</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="42"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="48"/>
        <source>MX System Sounds</source>
        <translation>MX Systémové zvuky</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="48"/>
        <source>This app is Xfce-only</source>
        <translation>Tato aplikace je pouze pro Xfce</translation>
    </message>
</context>
</TS>

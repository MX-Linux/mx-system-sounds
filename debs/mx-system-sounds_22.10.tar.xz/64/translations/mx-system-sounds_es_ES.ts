<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>mxsystemsounds</name>
    <message>
        <location filename="mxsystemsounds.ui" line="14"/>
        <location filename="mxsystemsounds.cpp" line="70"/>
        <location filename="mxsystemsounds.cpp" line="288"/>
        <location filename="mxsystemsounds.cpp" line="300"/>
        <location filename="mxsystemsounds.cpp" line="334"/>
        <source>MX System Sounds</source>
        <translation>MX Sonidos del Sistema</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="48"/>
        <source>Event Sounds</source>
        <translation>Sonidos de eventos</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="61"/>
        <source>Session Sounds</source>
        <translation>Sonidos de la sesión</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="68"/>
        <source>XFCE Event Sounds</source>
        <translation>Sonidos de eventos de XFCE</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="75"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="82"/>
        <source>XFCE Input Feedback Sounds</source>
        <translation>XFCE sonidos de reacción a la entrada</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="89"/>
        <source>Logout</source>
        <translation>Cerrar sesión</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="118"/>
        <source>Custom Sounds</source>
        <translation>Sonidos personalizados</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="125"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="132"/>
        <location filename="mxsystemsounds.ui" line="153"/>
        <source>Login Sound</source>
        <translation>Sonido de Inicio de sesion</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="139"/>
        <location filename="mxsystemsounds.ui" line="185"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="164"/>
        <location filename="mxsystemsounds.ui" line="207"/>
        <location filename="mxsystemsounds.ui" line="210"/>
        <source>Theme Default</source>
        <translation>Tema por defecto</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="167"/>
        <source>Use Default</source>
        <translation>Usar predeterminado</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="178"/>
        <location filename="mxsystemsounds.ui" line="196"/>
        <source>Logout Sound</source>
        <translation>Sonido de Cierre de sesion</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="229"/>
        <source>Borealis</source>
        <translation>Borealis</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="260"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="263"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="270"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="286"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="289"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="296"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="354"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="380"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="383"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.ui" line="390"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="287"/>
        <source>About MX System Sounds</source>
        <translation>Acerca de MX sonidos del sistema</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="288"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="289"/>
        <source>Configure Event &amp; Session Sounds</source>
        <translation>Configurar sonidos de Eventos y Sesión</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="291"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="292"/>
        <location filename="mxsystemsounds.cpp" line="300"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="293"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="294"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="309"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="353"/>
        <location filename="mxsystemsounds.cpp" line="383"/>
        <source>Select Sound File</source>
        <translation>Seleccione archivo de sonido</translation>
    </message>
    <message>
        <location filename="mxsystemsounds.cpp" line="353"/>
        <location filename="mxsystemsounds.cpp" line="383"/>
        <source>Sound Files (*.mp3 *.m4a *.aac *.flac *.ogg *.oga *.wav)</source>
        <translation>Archivos de sonido (*.mp3 *.m4a *.aac *.flac *.ogg *.oga *.wav)</translation>
    </message>
</context>
</TS>
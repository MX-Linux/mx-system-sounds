<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="hr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="70"/>
        <location filename="../mainwindow.cpp" line="255"/>
        <location filename="../mainwindow.cpp" line="274"/>
        <source>MX System Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="48"/>
        <source>Event Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="61"/>
        <source>Session Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="68"/>
        <source>XFCE Event Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="75"/>
        <source>Login</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>XFCE Input Feedback Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="89"/>
        <source>Logout</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>Custom Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="125"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="132"/>
        <location filename="../mainwindow.ui" line="153"/>
        <source>Login Sound</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="139"/>
        <location filename="../mainwindow.ui" line="185"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="164"/>
        <location filename="../mainwindow.ui" line="207"/>
        <location filename="../mainwindow.ui" line="210"/>
        <source>Theme Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Use Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="178"/>
        <location filename="../mainwindow.ui" line="196"/>
        <source>Logout Sound</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Borealis</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="260"/>
        <source>About this application</source>
        <translation>O ovoj aplikaciji</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="270"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="286"/>
        <source>Display help </source>
        <translation>Prikaži pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="296"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="354"/>
        <source>Apply</source>
        <translation>Primjeni</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="380"/>
        <source>Quit application</source>
        <translation>Zatvori aplikaciju</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Close</source>
        <translation>Zatvori</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="390"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="254"/>
        <source>About MX System Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="256"/>
        <source>Version: </source>
        <translation>Inačica:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="257"/>
        <source>Configure Event &amp; Session Sounds</source>
        <translation>Configure Event &amp; Session Sounds</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="259"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Autorska prava (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>%1 License</source>
        <translation>%1 Licenca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="274"/>
        <source>%1 Help</source>
        <translation>%1 Pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="289"/>
        <location filename="../mainwindow.cpp" line="318"/>
        <source>Select Sound File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="289"/>
        <location filename="../mainwindow.cpp" line="318"/>
        <source>Sound Files (*.mp3 *.m4a *.aac *.flac *.ogg *.oga *.wav)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="40"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="41"/>
        <location filename="../about.cpp" line="51"/>
        <source>Changelog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="42"/>
        <source>Cancel</source>
        <translation>Otkaži</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="63"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvori</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="48"/>
        <source>MX System Sounds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="48"/>
        <source>This app is Xfce-only</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>